var mymap = L.map('mapid').setView([16.741170, 100.192108], 13);

L.tileLayer('https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}', {
    attributions: '&copy; <a href="https://www.google.co.th/maps/">Google</a>'
}).addTo(mymap);



var geojson = L.layerGroup().addTo(mymap)
var json_food = L.geoJson(food).addTo(geojson)
mymap.fitBounds(json_food.getBounds())

function onMapClick(e) {
    geojson.clearLayers()
    var point = turf.point([e.latlng.lng, e.latlng.lat])
    var buffered = turf.buffer(point, 0.5, { units: 'kilometers' })
    L.geoJson(point).addTo(geojson)
    L.geoJson(buffered).addTo(geojson)

    var ptsWithin = turf.pointsWithinPolygon(food, buffered)
    console.log(ptsWithin);

    L.geoJson(ptsWithin).addTo(geojson)

    for (var i = 0; i < ptsWithin.features.length; i++) {
        var greatCircle = turf.greatCircle(point, ptsWithin.features[i], { 'name': '' });
        L.geoJson(greatCircle).addTo(geojson)
        console.log(greatCircle);
    }

}
mymap.on('click', onMapClick);
