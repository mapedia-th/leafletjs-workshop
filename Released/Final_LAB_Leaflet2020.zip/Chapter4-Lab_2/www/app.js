var mymap = L.map('mapid').setView([16.821317, 100.235372], 12);

var mapnik = L.tileLayer('http://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png', {
  maxZoom: 18,
}).addTo(mymap);


var house = L.markerClusterGroup().addTo(mymap)

var household_icon = L.icon({
  iconUrl: 'img/home.png',
  iconSize: [40, 40]
});

$.getJSON("/api_household", function (data) {
  console.log(data);

  for (var i = 0; i < data.features.length; i++) {
    var a = data.features[i].geometry.coordinates
    var propertie = data.features[i].properties

    var popup = '<table class="table">\
        <thead>\
          <tr>\
            <th>คำอธิบาย</th>\
            <th>ข้อมูล</th>\
          </tr>\
        </thead>\
        <tbody>\
        <tr>\
          <td>รูปประจำตัว</td>\
          <td> <img src=" '+ propertie.pic_medium + '  " width="100%"></td>\
        </tr>\
        <tr>\
          <td>ชื่อ - นามสกุล</td>\
          <td>'+ propertie.fname + ' ' + propertie.sname + '</td>\
        </tr>\
        <tr>\
          <td>เพศ</td>\
          <td>'+ propertie.gender + '</td>\
        </tr>\
        <tr>\
          <td>อายุ</td>\
          <td>'+ propertie.age + '</td>\
        </tr>\
        <tr>\
          <td>wt</td>\
          <td>'+ propertie.wt + '</td>\
        </tr>\
        <tr>\
          <td>ht</td>\
          <td>'+ propertie.ht + '</td>\
        </tr>\
        <tr>\
          <td>tb_th</td>\
          <td>'+ propertie.tb_th + '</td>\
        </tr>\
        <tr>\
          <td>ap_th</td>\
          <td>'+ propertie.ap_th + '</td>\
        </tr>\
        </tbody>\
      </table>'

    var marker = L.marker(new L.LatLng(a[1], a[0]), { icon: household_icon })
      .bindPopup(popup)
      .addTo(house)

  }

})


var hospital = L.layerGroup().addTo(mymap)
var hospital_data = []
$.getJSON("/api_hospital", function (data) {
  L.geoJson(data, {
    pointToLayer: function (feature, latlng) {
      var hospital_icon = L.icon({
        iconUrl: 'img/hospital.png',
        iconSize: [40, 40]
      });
      return new L.marker([latlng.lat, latlng.lng], {
        opacity: 1,
        icon: hospital_icon,
      });
    },
  }).addTo(hospital)
  hospital_data = data
})



var buffer = L.layerGroup().addTo(mymap)

$("#form_query").submit(function (event) {
  event.preventDefault();
  house.clearLayers();
  buffer.clearLayers();

  var disease = event.target.disease.value
  var gender = event.target.gender.value
  var radius = event.target.radius.value

  $.ajax({
    url: '/house_search',
    method: 'post',
    data: ({
      disease: disease,
      gender: gender,
      radius: radius
    }),
    success: function (data) {
      console.log(hospital_data);

      if (radius != 0) {
        for (var i = 0; i < hospital_data.features.length; i++) {
          var lat = hospital_data.features[i].geometry.coordinates[1]
          var lon = hospital_data.features[i].geometry.coordinates[0]
          L.circle([lat, lon], {
            radius: radius
          }).addTo(buffer)
        }
      }

      console.log(data);
      var household_icon = L.icon({
        iconUrl: 'img/home.png',
        iconSize: [40, 40]
      });

      for (var i = 0; i < data.features.length; i++) {
        var a = data.features[i].geometry.coordinates
        var propertie = data.features[i].properties

        var popup = '<table class="table">\
                <thead>\
                  <tr>\
                    <th>คำอธิบาย</th>\
                    <th>ข้อมูล</th>\
                  </tr>\
                </thead>\
                <tbody>\
                <tr>\
                  <td>รูปประจำตัว</td>\
                  <td> <img src=" '+ propertie.pic_medium + '  " width="100%"></td>\
                </tr>\
                <tr>\
                  <td>ชื่อ - นามสกุล</td>\
                  <td>'+ propertie.fname + ' ' + propertie.sname + '</td>\
                </tr>\
                <tr>\
                  <td>เพศ</td>\
                  <td>'+ propertie.gender + '</td>\
                </tr>\
                <tr>\
                  <td>อายุ</td>\
                  <td>'+ propertie.age + '</td>\
                </tr>\
                <tr>\
                  <td>wt</td>\
                  <td>'+ propertie.wt + '</td>\
                </tr>\
                <tr>\
                  <td>ht</td>\
                  <td>'+ propertie.ht + '</td>\
                </tr>\
                <tr>\
                  <td>tb_th</td>\
                  <td>'+ propertie.tb_th + '</td>\
                </tr>\
                <tr>\
                  <td>ap_th</td>\
                  <td>'+ propertie.ap_th + '</td>\
                </tr>\
                </tbody>\
              </table>'

        var marker = L.marker(new L.LatLng(a[1], a[0]), { icon: household_icon })
          .bindPopup(popup)
          .addTo(house)


      }


    }, error: function () {
      console.log('error  data!');
    }
  })

})


function onMapClick(e) {
  console.log(e.latlng);
  house.clearLayers();
  buffer.clearLayers();

  $.ajax({
    url: '/search_point',
    method: 'post',
    data: ({
      lat: e.latlng.lat,
      lng: e.latlng.lng,
    }),
    success: function (data) {
      console.log(hospital_data);


      L.circle([e.latlng.lat, e.latlng.lng], {
        radius: 2000
      }).addTo(buffer)

      console.log(data);
      var household_icon = L.icon({
        iconUrl: 'img/home.png',
        iconSize: [40, 40]
      });

      for (var i = 0; i < data.features.length; i++) {
        var a = data.features[i].geometry.coordinates
        var propertie = data.features[i].properties

        var popup = '<table class="table">\
                <thead>\
                  <tr>\
                    <th>คำอธิบาย</th>\
                    <th>ข้อมูล</th>\
                  </tr>\
                </thead>\
                <tbody>\
                <tr>\
                  <td>รูปประจำตัว</td>\
                  <td> <img src=" '+ propertie.pic_medium + '  " width="100%"></td>\
                </tr>\
                <tr>\
                  <td>ชื่อ - นามสกุล</td>\
                  <td>'+ propertie.fname + ' ' + propertie.sname + '</td>\
                </tr>\
                <tr>\
                  <td>เพศ</td>\
                  <td>'+ propertie.gender + '</td>\
                </tr>\
                <tr>\
                  <td>อายุ</td>\
                  <td>'+ propertie.age + '</td>\
                </tr>\
                <tr>\
                  <td>wt</td>\
                  <td>'+ propertie.wt + '</td>\
                </tr>\
                <tr>\
                  <td>ht</td>\
                  <td>'+ propertie.ht + '</td>\
                </tr>\
                <tr>\
                  <td>tb_th</td>\
                  <td>'+ propertie.tb_th + '</td>\
                </tr>\
                <tr>\
                  <td>ap_th</td>\
                  <td>'+ propertie.ap_th + '</td>\
                </tr>\
                </tbody>\
              </table>'

        var marker = L.marker(new L.LatLng(a[1], a[0]), { icon: household_icon })
          .bindPopup(popup)
          .addTo(house)


      }

    }, error: function () {
      console.log('error  data!');
    }
  })

}
//mymap.on('click', onMapClick);

mymap.pm.addControls({
  position: 'topright',
  drawCircle: true,
  drawMarker: true,
  drawCircleMarker: true,
  drawPolyline: true,
  removalMode: true,
  cutPolygon: true,
  dragMode: true,
  editMode: true
});



mymap.on('pm:create', async function (e) {
  var lyr = e.layer;
  var geom = (JSON.stringify(lyr.toGeoJSON().geometry))
  console.log(geom);
  // mymap.removeLayer(lyr);

  $.ajax({
    url: '/search_by_area',
    method: 'post',
    data: ({
      geom: geom
    }),
    success: function (data) {
      console.log(data);
      house.clearLayers();
      console.log(data);

      var household_icon = L.icon({
        iconUrl: 'img/home.png',
        iconSize: [40, 40]
      });

      for (var i = 0; i < data.features.length; i++) {
        var a = data.features[i].geometry.coordinates
        var propertie = data.features[i].properties

        var popup = '<table class="table">\
                <thead>\
                  <tr>\
                    <th>คำอธิบาย</th>\
                    <th>ข้อมูล</th>\
                  </tr>\
                </thead>\
                <tbody>\
                <tr>\
                  <td>รูปประจำตัว</td>\
                  <td> <img src=" '+ propertie.pic_medium + '  " width="100%"></td>\
                </tr>\
                <tr>\
                  <td>ชื่อ - นามสกุล</td>\
                  <td>'+ propertie.fname + ' ' + propertie.sname + '</td>\
                </tr>\
                <tr>\
                  <td>เพศ</td>\
                  <td>'+ propertie.gender + '</td>\
                </tr>\
                <tr>\
                  <td>อายุ</td>\
                  <td>'+ propertie.age + '</td>\
                </tr>\
                <tr>\
                  <td>wt</td>\
                  <td>'+ propertie.wt + '</td>\
                </tr>\
                <tr>\
                  <td>ht</td>\
                  <td>'+ propertie.ht + '</td>\
                </tr>\
                <tr>\
                  <td>tb_th</td>\
                  <td>'+ propertie.tb_th + '</td>\
                </tr>\
                <tr>\
                  <td>ap_th</td>\
                  <td>'+ propertie.ap_th + '</td>\
                </tr>\
                </tbody>\
              </table>'

        var marker = L.marker(new L.LatLng(a[1], a[0]), { icon: household_icon })
          .bindPopup(popup)
          .addTo(house)


      }

    }, error: function () {
      console.log('error  data!');
    }
  })


});
